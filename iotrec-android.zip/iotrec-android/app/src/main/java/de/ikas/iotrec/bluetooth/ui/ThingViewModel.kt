package de.ikas.iotrec.bluetooth.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.viewModelScope
import de.ikas.iotrec.database.db.IotRecDatabase
import de.ikas.iotrec.database.model.Thing
import de.ikas.iotrec.database.repository.ThingRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

//import de.ikas.iotrec.database.model.Venue

class ThingViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: ThingRepository
    val allThings: LiveData<List<Thing>>

    init {
        val thingsDao = IotRecDatabase.getDatabase(application).thingDao()
        repository = ThingRepository(thingsDao)
        allThings = repository.allThings
    }

    fun insert(thing: Thing) = viewModelScope.launch(Dispatchers.IO) {
        repository.insert(thing)
    }
}