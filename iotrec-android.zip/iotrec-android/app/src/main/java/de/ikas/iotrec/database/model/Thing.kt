package de.ikas.iotrec.database.model
import androidx.room.Entity
import androidx.room.PrimaryKey


@Entity(tableName = "thing_table")
data class Thing(
    @PrimaryKey var id: Int,
    var title: String,
    var description: String,
    var uuid: String, //TODO uuid data type?
    var major: Int,
    var minor: Int
    // TODO add image
)