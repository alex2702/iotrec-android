package de.ikas.iotrec.database.dao

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import de.ikas.iotrec.database.model.Thing

@Dao
interface ThingDao {

    @Query("SELECT * from thing_table ORDER BY id ASC")
    fun getAllThings(): LiveData<List<Thing>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(thing: Thing)

    @Query("DELETE FROM thing_table")
    fun deleteAll()
}