package de.ikas.iotrec.network

import android.util.Log
import okhttp3.Interceptor
import okhttp3.Response

//source: https://medium.com/@theanilpaudel/using-the-power-of-retrofit-okhttp-and-dagger-2-for-jwt-token-authentication-ad8db6121eac

class TokenInterceptor constructor(private val token: String) : Interceptor {

    private val TAG = "TokenInterceptor"

    override fun intercept(chain: Interceptor.Chain) : Response {

        Log.d(TAG, "intercept()")

        val original = chain.request()

        Log.d(TAG, "original.url.encodedPath: " + original.url.encodedPath)
        Log.d(TAG, original.toString())

        // don't need a token when logging in or signing up
        if ((original.url.encodedPath.contains("/login/") && original.method.toLowerCase() == "post") || (original.url.encodedPath.endsWith("/users/") && original.method.toLowerCase() == "post")) {
            Log.d(TAG, "chain.proceed(original)")
            return chain.proceed(original)
        }

        val originalHttpUrl = original.url
        val requestBuilder = original.newBuilder().addHeader("Authorization", token).url(originalHttpUrl)

        val request = requestBuilder.build()
        Log.d(TAG, "chain.proceed(request)")
        return chain.proceed(request)
    }
}