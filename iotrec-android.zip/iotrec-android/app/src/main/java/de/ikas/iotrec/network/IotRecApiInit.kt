package de.ikas.iotrec.network

import de.ikas.iotrec.account.data.model.LoggedInUser
import de.ikas.iotrec.database.model.Thing
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import okhttp3.logging.HttpLoggingInterceptor.Level
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory

//private val iotRecApi: IotRecApi? = null

/*
object IotRecApiInit {

    private var tokenInterceptor = TokenInterceptor("")

    private val iotRecApiClient = OkHttpClient().newBuilder()
        //.cache(cache)
        .addInterceptor(tokenInterceptor)
        .build()

    val retrofit = Retrofit.Builder()
        .client(iotRecApiClient)
        .baseUrl("http://192.168.178.47:8000/api/")
        .addConverterFactory(MoshiConverterFactory.create())
        .build()

    val iotRecApi : IotRecApi = retrofit.create(IotRecApi::class.java)
}
*/

class IotRecApiInit {

    private val TAG = "IotRecApiInit"

    private val iotRecApi: IotRecApi

    init {

        //TODO
        //get the current token
        //attach it to the TokenInterceptor constructor

        val tokenInterceptor = TokenInterceptor("")

        val loggingInterceptor = HttpLoggingInterceptor()
        loggingInterceptor.setLevel(Level.BODY)

        val iotRecApiClient = OkHttpClient().newBuilder()
            //.cache(cache)
            .addInterceptor(tokenInterceptor)
            .addInterceptor(loggingInterceptor)
            .build()

        val retrofit = Retrofit.Builder()
            .client(iotRecApiClient)
            .baseUrl("http://192.168.178.47:8000/api/")
            .addConverterFactory(MoshiConverterFactory.create())
            .build()

        iotRecApi = retrofit.create(IotRecApi::class.java)
    }

    suspend fun login(username: String, password: String): Response<LoggedInUser> {
        return iotRecApi.login(username, password)
    }

    fun getThing(type: String, uuid: String, major: Int, minor: Int): Response<Thing> {
        return iotRecApi.getThing(type, uuid, major, minor)
    }
}