package de.ikas.iotrec.bluetooth.helper

import de.ikas.iotrec.database.model.Thing

class ThingManager() {

    fun getVenuesOfThings(things: Collection<Thing>) {

    }
}