package de.ikas.iotrec.database.db

import android.content.Context
import androidx.room.*
import androidx.sqlite.db.SupportSQLiteOpenHelper
import de.ikas.iotrec.database.dao.ThingDao
//import de.ikas.iotrec.database.dao.VenueDao
import de.ikas.iotrec.database.model.Thing

@Database(entities = [Thing::class], version = 1)
public abstract class IotRecDatabase : RoomDatabase() {

    companion object {
        @Volatile
        private var INSTANCE: IotRecDatabase? = null

        fun getDatabase(context: Context): IotRecDatabase {
            return INSTANCE ?: synchronized(this) {
                // Create database here
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    IotRecDatabase::class.java,
                    "iotrec_database"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }

    abstract fun thingDao(): ThingDao
    //abstract fun venueDao(): VenueDao


    override fun createOpenHelper(config: DatabaseConfiguration?): SupportSQLiteOpenHelper {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }

    override fun createInvalidationTracker(): InvalidationTracker {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }

    override fun clearAllTables() {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }


}