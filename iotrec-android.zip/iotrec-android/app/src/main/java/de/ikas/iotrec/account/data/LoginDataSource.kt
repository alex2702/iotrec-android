package de.ikas.iotrec.account.data

import android.util.Log
import de.ikas.iotrec.account.data.model.LoggedInUser
import de.ikas.iotrec.account.data.model.User
import de.ikas.iotrec.network.IotRecApiInit
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.async
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.await
import java.io.IOException
import kotlinx.coroutines.*

/**
 * Class that handles authentication w/ login credentials and retrieves user information.
 */
class LoginDataSource(private val iotRecApi: IotRecApiInit = IotRecApiInit()) {

    private val TAG = "LoginDataSource"

    suspend fun login(username: String, password: String): Response<LoggedInUser> {
    //fun login(username: String, password: String): Response<LoggedInUser>> {

        val result = iotRecApi.login(username, password)
        Log.d(TAG, result.toString())
        return result

        /*
        try {



            /*
            if(result.isSuccessful) {
                val loggedInUser = result.body()
                return Result.Success(loggedInUser)
            } else {
                Log.d(TAG, "call failed")
            }
            */

            /*
            call.enqueue(object : Callback<LoggedInUser> {
                override fun onFailure(call: Call<LoggedInUser>?, t: Throwable?) {
                    Log.d(TAG, "call failed")
                }

                override fun onResponse(call: Call<LoggedInUser>?, response: Response<LoggedInUser>?) {
                    val loggedInUser = response
                    val fakeUser = LoggedInUser(java.util.UUID.randomUUID().toString(), User("Jane Doe"))
                    return Result.Success(fakeUser)


                    if(response!!.isSuccessful)
                        Log.d(TAG, response?.body().toString())

                        return Result.Success(response)
                    else


                }

            })
            */


            //val fakeUser = LoggedInUser(java.util.UUID.randomUUID().toString(), User("Jane Doe"))
            //return Result.Success(fakeUser)
        } catch (e: Throwable) {
            //return Result.Error(IOException("Error logging in", e))
            Log.d(TAG, e.toString())
            return Response.error(500, Response())
        }
        */
    }

    fun logout() {
        // TODO: revoke authentication
    }
}
