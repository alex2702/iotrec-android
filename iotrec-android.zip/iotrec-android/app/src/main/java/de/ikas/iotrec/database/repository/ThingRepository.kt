package de.ikas.iotrec.database.repository

import androidx.annotation.WorkerThread
import androidx.lifecycle.LiveData
import de.ikas.iotrec.database.dao.ThingDao
import de.ikas.iotrec.database.model.Thing

class ThingRepository(private val thingDao: ThingDao) {
    val allThings: LiveData<List<Thing>> = thingDao.getAllThings()

    @WorkerThread
    suspend fun insert(thing: Thing) {
        thingDao.insert(thing)
    }
}